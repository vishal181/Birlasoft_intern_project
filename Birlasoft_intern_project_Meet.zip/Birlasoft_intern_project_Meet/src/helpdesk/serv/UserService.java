package helpdesk.serv;

import helpdesk.dao.UserDaoImpl;

public class UserService {
    UserDaoImpl ui = new UserDaoImpl();
    
    public boolean isLogin(String email, String password){     
        ui.connect();
        boolean idn1 = ui.getId(email, password);
        return idn1;
    }
    
    public int getId(String email) {
        ui.connect();
        int id = ui.getId(email);
        return id;
    }

    public String getRole(int id) {
        ui.connect();
        String role = ui.getRole(id);
        return role;
    }
    
}
