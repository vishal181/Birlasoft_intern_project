package helpdesk.serv;

import helpdesk.dao.TicketDaoImpl;

public class TicketService {
	  TicketDaoImpl ti = new TicketDaoImpl();

    public boolean CreateTicket(int id, String catg, String title, String descr){
    	ti.connect();
        boolean ct = ti.CreateTicket(id, catg, title, descr);
        return ct;
    }
    public void Open_Tickets(int id, String catg){
        ti.connect();
        ti.Open_Tickets(id,catg);
    }

    public void OpenTickets(int id){
        ti.connect();
        ti.OpenTickets(id);

    }
    public void ClosedTickets(int id){
        ti.connect();
        ti.ClosedTickets(id);

    }
    public void Closed_Tickets(int id, String catg){
        ti.connect();
        ti.Closed_Tickets(id,catg);

    }

    public void ViewTicket(int id){
        ti.connect();
        ti.ViewTicket(id);

    }

    public  void setFeedback(int id, String feedback) {
        ti.connect();
        ti.setFeedback(id, feedback);
    }

    public void setSoln(int id, String soln) {
        ti.connect();
        ti.setSoln(id, soln);
    }
    

    public void CloseStatus(int id) {
        ti.connect();
        ti.CloseStatus(id);
    }

    public void AllTickets(int id) {
        ti.connect();
        ti.AllTickets(id);
        
    }
    public void ShowAllTickets() {
        ti.connect();
        ti.ShowAllTickets();    
    }
    
    public void ByCatg(String catg) {
        ti.connect();
        ti.ByCatg(catg);
        
    }
    
}
