package helpdesk;
import java.util.InputMismatchException;
import java.util.Scanner;
import helpdesk.serv.TicketService;
import helpdesk.serv.UserService;

/**
 * Helpdesk
 */
public class Helpdesk {
    public static void main(String[] args){
    	Helpdesk h = new Helpdesk();
        System.out.println("----------------");
        System.out.println("HelpDesk Portal");
        System.out.println("----------------");
        h.Login();
    }
    public void Login() {
    	UserService us = new UserService();
    	Scanner sc= new Scanner(System.in);
    	try {
    	System.out.println("-----------------");
        System.out.println("Press 1 to Login");
        System.out.println("Press 2 to Exit ");
        System.out.println("-----------------");
        System.out.println("-----------------");
        System.out.println("Enter your choice: ");
        System.out.println("-----------------");
        int option = sc.nextInt();
        if(option==1)
        {
        System.out.println("");
        System.out.println("Email:");  
        String email= sc.next(); 
        System.out.println("Password:");  
        String password= sc.next();
        boolean idn = us.isLogin(email, password);
        //
        if (!idn) {
        	System.out.println("");
        	System.out.println("----------------");
            System.out.println("Failed to login ");
            System.out.println("----------------");
            Login();
        } 
        else {
        	int id1 = us.getId(email);
            String role1 = us.getRole(id1);
        	System.out.println("");
        	System.out.println("----------------------------------");
            System.out.println("logged In  Role: "+ role1 +" ID: "+id1);
            System.out.println("----------------------------------");
            if (role1.equals("user")) {
            	UserDash(id1);
            }
            else if (role1.equals("IT Support")) {
            	ITDash(id1);
            }
            else {
            	AdminDash(id1);
            }
        }
        }
        else if(option==2) {
        	System.exit(0);
        }
        else {
        	System.out.println("");
        	System.out.println("Please enter a valid choice");
        	Login();
        }
    	}
    	catch(Exception e) {
    	    System.out.println("Please enter a valid input");
    	    Login();
    	}

        sc.close();
    }
    public void AdminDash(int id1) {
    	TicketService ts = new TicketService();
    	Scanner sc= new Scanner(System.in);
    	try {
    	System.out.println("");
    	System.out.println("********************");
    	System.out.println("  Admin Dashboard");
    	System.out.println("********************");
    	System.out.println("1. Show Ticket History ");
    	System.out.println("2. Tickets by Category with open status");
    	System.out.println("3. Logout ");
        System.out.println("");
        System.out.println("Please Enter Your Choice");
        int key = sc.nextInt();
        if (key==1) {
        	 ts.ShowAllTickets();
             AdminDash(id1);
        }
        else if (key==2) {
            String catg = "";
            System.out.println("Select Category");
            System.out.println("0.Go Back");
            System.out.println("1.Software");
            System.out.println("2.Hardware");
            System.out.println("3.Network");
            int k5 = sc.nextInt();
            if(k5==0) {
            	ITDash(id1);
            }else if(k5== 1){
                catg = "Software";
            }else if(k5 == 2){
                catg = "Hardware";
            }else if(k5 == 3){
                catg = "Network";
            }
            ts.ByCatg(catg);
            AdminDash(id1);	
       }
        else {
        	Login();
        }
    	}
    	catch(Exception e) {
    	    System.out.println("Please Enter A Valid Input");
    	    AdminDash(id1);
    	}
        sc.close();
    }
    public void UserDash(int id1) {
    	        TicketService ts = new TicketService();
    	        Scanner sc= new Scanner(System.in);
    	    	try {
            	System.out.println("");
            	System.out.println("********************");
            	System.out.println("  User Dashboard");
            	System.out.println("********************");
            	
                System.out.println("1.Create Ticket ");
                System.out.println("2.View Open Tickets");  
                System.out.println("3.Ticket History");
                System.out.println("4.Logout");
                System.out.println("");
                System.out.println("Please Enter Your Choice");
                int key = sc.nextInt();
                
                switch (key) {
                    case 1:
                    
                    String catg = "";
                    System.out.println("");
                    System.out.println("Ticket Creation");
                    System.out.println("Select Category");
                    System.out.println("0.Go Back");
                    System.out.println("1.Software");
                    System.out.println("2.Hardware");
                    System.out.println("3.Network");
                    System.out.println("");
                    System.out.println("Please Enter Your Choice");
                    
                    int cat = sc.nextInt();
                    if(cat == 0){
                        UserDash(id1);
                    }
                    else if(cat == 1){
                        catg = "Software";
                    }
                    else if(cat == 2){
                        catg = "Hardware";
                    }
                    else if(cat == 3){
                        catg = "Network";
                    }
                        System.out.println("");
                        System.out.println("Title:");
                        String title = sc.next();
                        System.out.println("Detials: ");
                        String descr = sc.next();
                        ts.CreateTicket(id1, catg, title, descr);
                        System.out.println("");
                        System.out.println("----------------------------");
                        System.out.println("Ticket Created Successfully ");
                        System.out.println("----------------------------");
                        UserDash(id1);
                        break;
                        
                        
                    case 2: 
                    	System.out.println("");
                        ts.OpenTickets(id1);
                        System.out.println("");
                        System.out.println("**** Press 0 to Exit ****");
                        System.out.println("OR Enter Ticket ID To Edit: ");
                        int tid = sc.nextInt();
                        if(tid==0)
                        {
                          UserDash(id1);	
                        }

                        ts.ViewTicket(tid);
                        System.out.println("1.Feedback");
                        System.out.println("2.Close Ticket");
                        System.out.println("3.Go Back");
                        System.out.println("------------------");
                        System.out.println("Enter Your Option ");
                        int et = sc.nextInt();

                        switch (et) {
                            case 1:
                            	System.out.println("");
                                System.out.println("Enter Your Feedback: ");
                                String feedback = sc.next();
                                ts.setFeedback(tid, feedback);
                                break;
                        
                            case 2:
                            	System.out.println("");
                            	System.out.println("----------------------------");
                                System.out.println("Ticket Closed Successfully");
                                System.out.println("----------------------------");
                                ts.CloseStatus(tid);
                                break;
                            case 3:
                            	UserDash(id1);
                        }
                        UserDash(id1);
                        break;
                    

                    case 3: 
                    ts.ClosedTickets(id1);
                    UserDash(id1);
                        break;
                    case 4:
                    	System.out.println("-----------------------");
                        System.out.println("Logged Out Successfully");
                        System.out.println("-----------------------");
                    	System.out.println("");
                    	Login();
                    default:
                        System.out.println("Enter Valid Option");
                        UserDash(id1);
                    	
                }
    	    	}
    	    	catch(Exception e) {
    	    	    System.out.println("Please Enter A Valid Input");
    	    	    UserDash(id1);
    	    	}
                sc.close();
            }
                
        public void ITDash(int id1){
        	    TicketService ts =new TicketService();
        	    Scanner sc= new Scanner(System.in);
        	    try {
            	System.out.println("");
            	System.out.println("********************");
            	System.out.println("   IT Dashboard");
            	System.out.println("********************");
            	System.out.println("");
                System.out.println("1.View Tickets");
                System.out.println("2.Ticket History");
                System.out.println("3.Logout");
                System.out.println("");
                System.out.println("Please Enter Your Choice");
                int k3 = sc.nextInt();
                String catg ="";
                if(id1==4)
                {
                	catg="Software";
                }
                else if(id1==5) {
                	catg="Hardware";
                }
                else {
                	catg="Network";
                }

                switch (k3) {
                    case 1:              	
                        ts.Open_Tickets(id1,catg);
                        System.out.println("**** Press 0 to Exit ****");
                        System.out.println("Or Enter Ticket ID To Edit: ");
                        int ticid = sc.nextInt();
                        if(ticid==0)
                        {
                          ITDash(id1);	
                        }
                        ts.ViewTicket(ticid);
                        System.out.println("1.Provide Solution: ");
                        System.out.println("2.Close Status");
                        System.out.println("3.Go Back");

                        int k4 = sc.nextInt();
                        if (k4 == 1) {
                                System.out.println("Solution: ");
                                String soln = sc.next();
                                ts.setSoln(ticid, soln);
                                ITDash(id1);
                        }
                        else if(k4 == 2){
                                ts.CloseStatus(ticid);  
                                ITDash(id1);
                        }
                        else {
                        	ITDash(id1);
                        }
                        break;
                
                    case 2:                 	
                        ts.Closed_Tickets(id1,catg);
                        ITDash(id1);
                        break;
                    case 3:
                    	System.out.println("-----------------------");
                        System.out.println("Logged Out Successfully");
                        System.out.println("-----------------------");
                    	System.out.println("");
                    	Login();
                    default:
                        System.out.println("Enter Valid Option");
                        ITDash(id1);
                }
        	    }
        	    catch(Exception e) {
            	    System.out.println("Please Enter A Valid Input");
            	    ITDash(id1);
            	}
                sc.close();
          }
        
    
}