package helpdesk;

import java.util.Scanner;

import helpdesk.serv.TicketService;
import helpdesk.serv.UserService;

/**
 * Helpdesk
 */
public class Helpdesk_1 {
    public static void main(String[] args){
        System.out.println("----------------");
        System.out.println("HelpDesk Portal");
        System.out.println("----------------");
        System.out.println("");
        Login();
    }
    public static void Login() {
    	Scanner input = new Scanner(System.in);

        System.out.println("Email:");  
        String email= input.next(); 
        System.out.println("Password:");  
        String password= input.next();

        boolean idn = UserService.isLogin(email, password);
        //
        
        if (!idn) {
        	System.out.println("");
        	System.out.println("----------------");
            System.out.println("Failed TO Login ");
            System.out.println("----------------");
        } 
        else {
        	int id1 = UserService.getId(email);
            String role1 = UserService.getRole(id1);
        	System.out.println("");
        	System.out.println("----------------------------------");
            System.out.println("logged In          Role: "+ role1);
            System.out.println("----------------------------------");
            if (role1.equals("user")) {
            	UserDash(id1);
            }
            else {
            	AdminDash(id1);
            }
        }
        input.close();
    }
    public static void UserDash(int id1) {
    	Scanner input = new Scanner(System.in);

            	System.out.println("");
            	System.out.println("********************");
            	System.out.println("  User Dashboard");
            	System.out.println("********************");
            	
                System.out.println("1.Create Ticket ");
                System.out.println("2.View Open Tickets");  
                System.out.println("3.Ticket History");
                System.out.println("4.Logout");
                System.out.println("");
                System.out.println("Please Enter Your Choice");
                int key = input.nextInt();
                
                switch (key) {
                    case 1:

                    
                    String catg = "";
                    System.out.println("");
                    System.out.println("Ticket Creation");
                    System.out.println("Select Categoryp");
                    System.out.println("0.Go Back");
                    System.out.println("1.Software");
                    System.out.println("2.Hardware");
                    System.out.println("3.Network");
                    System.out.println("");
                    System.out.println("Please Enter Your Choice");
                    
                    int cat = input.nextInt();
                    if(cat == 0){
                        UserDash(id1);
                    }
                    else if(cat == 1){
                        catg = "Software";
                    }
                    else if(cat == 2){
                        catg = "Hardware";
                    }
                    else if(cat == 3){
                        catg = "Network";
                    }
                  
                        System.out.println("");
                        System.out.println("Title:");
                        String title = input.next();
                        System.out.println("Detials: ");
                        String descr = input.next();
                        TicketService.CreateTicket(id1, catg, title, descr);
                        System.out.println("");
                        System.out.println("----------------------------");
                        System.out.println("Ticket Created Successfully ");
                        System.out.println("----------------------------");
                        UserDash(id1);
                       
                        break;
                        
                        
                    case 2: 
                    	System.out.println("");
                        TicketService.OpenTickets(id1);
                        System.out.println("");
                        System.out.println("**** Press 0 to Exit ****");
                        System.out.println("OR Enter Ticket ID To Edit: ");
                        int tid = input.nextInt();
                        if(tid==0)
                        {
                          UserDash(id1);	
                        }

                        TicketService.ViewTicket(tid);
                        System.out.println("1.Feedback");
                        System.out.println("2.Close Ticket");
                        System.out.println("3.Go Back");
                        System.out.println("------------------");
                        System.out.println("Enter Your Option ");
                        int et = input.nextInt();

                        switch (et) {
                            case 1:
                            
                            	System.out.println("");
                                System.out.println("Enter Your Feedback: ");
                                String feedback = input.next();
                                TicketService.setFeedback(tid, feedback);
                                
                                break;
                        
                            case 2:
                            	System.out.println("");
                            	System.out.println("----------------------------");
                                System.out.println("Ticket Closed Successfully");
                                System.out.println("----------------------------");
                                TicketService.CloseStatus(tid);
                                break;
                            case 3:
                            	UserDash(id1);
                        }
                        UserDash(id1);
                        break;
                    

                    case 3: 
                    TicketService.ClosedTickets(id1);
                    UserDash(id1);
                        break;
                    case 4:
                    	System.out.println("-----------------------");
                        System.out.println("Logged Out Successfully");
                        System.out.println("-----------------------");
                    	System.out.println("");
                    	Login();
                }
                input.close();
            }
                
        public static void AdminDash(int id1){
        	Scanner input = new Scanner(System.in);

            	System.out.println("");
            	System.out.println("********************");
            	System.out.println("Admin Dashboard");
            	System.out.println("********************");
            	System.out.println("");
                System.out.println("1.View Tickets");
                System.out.println("2.Tickets by category");
                System.out.println("3.Ticket History");
                System.out.println("4.Logout");
                System.out.println("");
                System.out.println("Please Enter Your Choice");
                int k3 = input.nextInt();

                switch (k3) {
                    case 1:              	
                        TicketService.OpenTickets(id1);
       
                        System.out.println("**** Press 0 to Exit ****");
                        System.out.println("OR Enter Ticket Id to Edit: ");
                        int ticid = input.nextInt();
                        if(ticid==0)
                        {
                          AdminDash(id1);	
                        }
                        TicketService.ViewTicket(ticid);
                        System.out.println("1.Provide Solution: ");
                        System.out.println("2.Close Status");
                        System.out.println("3.Go Back");

                        int k4 = input.nextInt();
                        if (k4 == 1) {
                                System.out.println("Solution: ");
                                String soln = input.next();
                                TicketService.setSoln(ticid, soln);
                               
                                AdminDash(id1);
                        }
                        else if(k4 == 2){
                                TicketService.CloseStatus(ticid);  
                                AdminDash(id1);
                        }
                        else {
                        	AdminDash(id1);
                        }
                      
                        break;


                    case 2:
                        String catg = "";
                        System.out.println("Select Category");
                        System.out.println("0.Go Back");
                        System.out.println("1.Software");
                        System.out.println("2.Hardware");
                        System.out.println("3.Network");
                        int k5 = input.nextInt();
                        if(k5==0) {
                        	AdminDash(id1);
                        }else if(k5== 1){
                            catg = "Software";
                        }else if(k5 == 2){
                            catg = "Hardware";
                        }else if(k5 == 3){
                            catg = "Network";
                        }
                        TicketService.ByCatg(catg);
                        AdminDash(id1);
                      
                        break;
                
                    case 3:                 
                        AdminDash(id1);
                        break;
                    case 4:
                    	System.out.println("-----------------------");
                        System.out.println("Logged Out Successfully");
                        System.out.println("-----------------------");
                    	System.out.println("");
                    	Login();
                }
                input.close();
          }
    
}