package helpdesk.dao;

import java.sql.*;

public class TicketDaoImpl implements TicketDao {

    String url = "jdbc:mysql://localhost:3306/helpdesk";
    String uname = "root";
    String pass = "root";

    Connection con = null;

    public void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, uname, pass);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    @Override
    public boolean CreateTicket(int id, String catg, String title, String descr) {
        boolean ct = false;

        String query = "insert into tickets (userid, category, title, descr) values ('" + id + "','"
                + catg + "','" + title + "','"+ descr + "')";

        try {
            Statement st = con.createStatement();
            int kk = st.executeUpdate(query);

            if (kk == 0) {
                ct = true;
            }

            // System.out.println(id.isEmpty());

            st.close();
            con.close();

        } catch (Exception e) {
            System.out.println(e);

        }

        return ct;

    }

    public void OpenTickets(int id) {

        String query = "SELECT tickets.ticketid, tickets.title, tickets.descr,ticketstatus.status FROM tickets RIGHT JOIN ticketstatus ON tickets.ticketid= ticketstatus.ticketid Where userid =" + id + " and status='Open'";

        try {

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
            	System.out.println("");
                System.out.println("TicketId   : " + rs.getString(1));
                System.out.println("Title      : " + rs.getString(2));
                System.out.println("Decription : " + rs.getString(3));
                System.out.println("Status   : " + rs.getString(4));
                System.out.println("");
            }

            st.close();
            con.close();

        } catch (Exception e) {
            System.out.println(e);

        }

    }

    public void ClosedTickets(int id) {

        String query = "select ticketid,userid,title,descr from tickets where userid ="+id+" ";

        try {

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
            	System.out.println("");
                System.out.println("TicketId   : " + rs.getString(1));
                System.out.println("User ID    : " + rs.getString(2));
                System.out.println("Title      : " + rs.getString(3));
                System.out.println("Decription : " + rs.getString(4));
                System.out.println("");
            }

            st.close();
            con.close();

        } catch (Exception e) {
            System.out.println(e);

        }

    }

    public void ViewTicket(int id) {

        String query = "select ticketid,userid,title,descr,category from tickets where ticketid ="+ id+"";

        try {

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
                System.out.println("TicketId   : " + rs.getString(1));
                System.out.println("Userid     : " + rs.getString(2));
                System.out.println("Title      : " + rs.getString(3));
                System.out.println("Decription : " + rs.getString(4));
                System.out.println("Category   : " + rs.getString(5));
                System.out.println("------------------");
            }

            st.close();
            con.close();

        } catch (Exception e) {
            System.out.println(e);

        }

    }

    public void setFeedback(int id, String feedback) {

        String query = "update ticketfeedback set feedback = '" + feedback + "' where ticketid = " + id;

        try {

            Statement st = con.createStatement();
            st.executeUpdate(query);

            // rs.next();

            st.close();
            con.close();

        } catch (Exception e) {
            System.out.println(e);

        }

    }

    public void setSoln(int id, String soln) {

        String query = "update ticketsolution set solution = '" + soln + "' where ticketid = " + id;

        try {

            Statement st = con.createStatement();
            st.executeUpdate(query);

            // rs.next();

            st.close();
            con.close();

        } catch (Exception e) {
            System.out.println(e);

        }

    }
    public void Closed_Tickets(int id) {

        String query = "select ticketid,userid,title,descr from tickets where userid ="+id+" ";

        try {

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
            	System.out.println("");
                System.out.println("TicketId   : " + rs.getString(1));
                System.out.println("User ID    : " + rs.getString(2));
                System.out.println("Title      : " + rs.getString(3));
                System.out.println("Decription : " + rs.getString(4));
                System.out.println("");
            }

            st.close();
            con.close();

        } catch (Exception e) {
            System.out.println(e);

        }

    }

    
    
    public void CloseStatus(int id) {

        String query = "update ticketstatus set status = 'closed' where ticketid = " + id;

        try {

            Statement st = con.createStatement();
            st.executeUpdate(query);

            // rs.next();

            st.close();
            con.close();

        } catch (Exception e) {
            System.out.println(e);

        }

    }

    public void AllTickets(int id) {

    	String query = "SELECT tickets.ticketid, tickets.title, tickets.descr,ticketstatus.status FROM tickets RIGHT JOIN ticketstatus ON tickets.ticketid= ticketstatus.ticketid Where userid =" + id + " and status='Open'";

        try {

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
            	System.out.println("");
                System.out.println("TicketId   : " + rs.getString(1));
                System.out.println("Title      : " + rs.getString(2));
                System.out.println("Decription : " + rs.getString(3));
                System.out.println("Status     : " + rs.getString(4));
                System.out.println("");
            }

            st.close();
            con.close();

        } catch (Exception e) {
            System.out.println(e);

        }


    }

    public void ByCatg(String catg) {
        String query ="SELECT tickets.ticketid,tickets.userid,tickets.category, tickets.title, tickets.descr,ticketstatus.status FROM tickets RIGHT JOIN ticketstatus ON tickets.ticketid= ticketstatus.ticketid Where category ='" + catg + "' and status='Open'";
      
        try {

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
                System.out.println("TicketId   : " + rs.getString(1));
                System.out.println("UserId     : " + rs.getString(2));
                System.out.println("Category   : " + rs.getString(3));
                System.out.println("Title      : " + rs.getString(4));
                System.out.println("Decription : " + rs.getString(5));
                System.out.println("Status     : " + rs.getString(6));
                System.out.println("------------------");
            }

            st.close();
            con.close();

        } catch (Exception e) {
            System.out.println(e);

        }

    }

}
