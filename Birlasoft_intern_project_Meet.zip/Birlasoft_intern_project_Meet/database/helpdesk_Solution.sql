CREATE TABLE `TicketSolution` (
  `ticketid` int NOT NULL AUTO_INCREMENT,
  `solution` varchar(45) NOT NULL,
  PRIMARY KEY (`ticketid`),
  UNIQUE KEY `idtickets_UNIQUE` (`ticketid`)
);
select * from TicketSolution;