CREATE TABLE `TicketStatus` (
  `ticketid` int NOT NULL AUTO_INCREMENT,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`ticketid`),
  UNIQUE KEY `idtickets_UNIQUE` (`ticketid`),
  CONSTRAINT `ticketid` FOREIGN KEY (`ticketid`) REFERENCES `tickets` (`ticketid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
ALTER TABLE ticketstatus DROP PRIMARY KEY;
INSERT INTO `TicketStatus` VALUES (18,'open'),(19,'closed'),(20,'open'),(21,'open'),(22,'closed');
INSERT INTO `TicketStatus` VALUES (24,'open');
select * from TicketStatus;
DELETE FROM ticketstatus;
ALTER TABLE ticketstatus DROP FOREIGN KEY ticketid;