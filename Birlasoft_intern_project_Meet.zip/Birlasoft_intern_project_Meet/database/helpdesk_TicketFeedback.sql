CREATE TABLE `TicketFeedback` (
  `ticketid` int NOT NULL AUTO_INCREMENT,
  `feedback` varchar(45) NOT NULL,
  PRIMARY KEY (`ticketid`),
  UNIQUE KEY `idtickets_UNIQUE` (`ticketid`)
);
select * from TicketFeedback;